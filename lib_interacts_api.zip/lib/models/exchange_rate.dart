class ExchangeRate{
  final String baseCode;
  final Map<String, dynamic> rates;

    ExchangeRate({
    required this.baseCode,
    required this.rates
  });
  
  factory ExchangeRate.fromJson(Map<String,dynamic> json){
    return ExchangeRate(
      baseCode: json['base_code'],
      rates: json['rates'],
    );
  }
}