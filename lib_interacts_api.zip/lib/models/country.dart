class Country{
  final String name;
  final String region;
  final String capital;
  final String flagUrl;
  final String currencyCode;

  Country({
    required this.name,
    required this.region,
    required this.capital,
    required this.flagUrl,
    required this.currencyCode,
  });
  
  factory Country.fromJson(Map<String, dynamic> json){
    return Country(
      name: json['name']['common'],
      region: json['region'],
      capital: json['capital'] != null ? json['capital'][0]: 'N/A',
      flagUrl: json['flags']['png'],
      currencyCode: json['currencies'] != null ? json['currencies'].keys.first: 'N/A',
    );
  }
}