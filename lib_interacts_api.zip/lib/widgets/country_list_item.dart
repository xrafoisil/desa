import 'package:flutter/material.dart';
import '../models/country.dart';
import '../screens/country_details_screen.dart';

class CountryListItem extends StatelessWidget{
   final Country country;
  CountryListItem({required this.country});

  
  @override
  Widget build(BuildContext context){
    return ListTile(
      leading: Image.network(country.flagUrl, height: 40, width: 40, fit: BoxFit.cover),
      title: Text(country.name),
    onTap: () {
        Navigator.push(
          context, 
          MaterialPageRoute(builder: (context) => CountryDetailsScreen(country: country)));
      },
    );
  }
}