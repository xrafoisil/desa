import 'package:flutter/material.dart';
import 'country_list_item.dart';
import '../models/country.dart';


class CountryList extends StatelessWidget {
  final List<Country> countries;

  CountryList({required this.countries});

    @override

      Widget build(BuildContext context) {
         return ListView.builder(
      itemCount: countries.length,
      itemBuilder: (context, index) {
        var country = countries[index];
        return CountryListItem(country: country);
      },
    );
  }
}