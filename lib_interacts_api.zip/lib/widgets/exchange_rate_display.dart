  import 'package:flutter/material.dart';
import '../models/exchange_rate.dart';

class ExchangeRateDisplay extends StatelessWidget{
  final ExchangeRate exchangeRate;
  final String currencyCode;

  ExchangeRateDisplay({required this.currencyCode, required this.exchangeRate});

@override
  Widget build(BuildContext context){
    double rate = exchangeRate.rates['USD'] / exchangeRate.rates[currencyCode];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Tasa de Cambio',style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('1 $currencyCode= ${rate.toStringAsFixed(2)} USD', style: TextStyle(fontSize: 16))
      ],
    );
  }
}