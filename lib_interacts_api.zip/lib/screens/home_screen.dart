import 'package:flutter/material.dart';
import '../widgets/country_list.dart';
import '../api_service.dart';
import '../models/country.dart';

class HomeScreen extends StatefulWidget {
  @override
    _HomeScreenState createState() => _HomeScreenState();
}


class _HomeScreenState extends State<HomeScreen> {
  final ApiService apiService = ApiService();
  late Future<List<Country>> countries;


@override
  void initState() {
    super.initState();
    countries = apiService.fetchCountries();
  }


  @override
  Widget build(BuildContext context) {
  return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Países'),
      ),
    body: FutureBuilder<List<Country>>(
    future: countries,
     builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            return CountryList(countries: snapshot.data!);
          }
        },
      ),
    );
  }
}






