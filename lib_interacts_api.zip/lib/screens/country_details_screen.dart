import 'package:flutter/material.dart';
import '../models/country.dart';
import '../api_service.dart';
import '../models/exchange_rate.dart';
import '../widgets/exchange_rate_display.dart';

class CountryDetailsScreen extends StatefulWidget {
  final Country country;
  CountryDetailsScreen({required this.country});

  @override
  _CountryDetailsScreenState createState() => _CountryDetailsScreenState();
}

class _CountryDetailsScreenState extends State<CountryDetailsScreen> {
  final ApiService apiService = ApiService();
  late Future<ExchangeRate> exchangeRate;

  @override
    void initState() {
    super.initState();
    exchangeRate = apiService.fetchExchangeRate(widget.country.currencyCode);
  }

    @override
     Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.country.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
  child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
  children: [
            Image.network(widget.country.flagUrl, height: 100, width: 150),
            SizedBox(height: 16),
            Text('Región: ${widget.country.region}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('Capital: ${widget.country.capital}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 16),
            FutureBuilder<ExchangeRate>(
              future: exchangeRate,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else {
                  return ExchangeRateDisplay(exchangeRate: snapshot.data!, currencyCode: widget.country.currencyCode);
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
