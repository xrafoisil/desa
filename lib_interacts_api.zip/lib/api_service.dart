import 'package:http/http.dart' as http;
import 'models/country.dart';
import 'models/exchange_rate.dart';
import 'dart:convert';

class ApiService{

  final String countriesApiUrl="https://restcountries.com/v3.1/all";
  final String exchangeRateApiUrl="https://open.er-api.com/v6/latest/";
  

Future<List<Country>> fetchCountries() async{
      final response = await http.get(Uri.parse(countriesApiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((item) => Country.fromJson(item)).toList();
 } else {
        throw Exception('Error al cargar los Paises');
      }
    }


Future<ExchangeRate> fetchExchangeRate(String currencyCode) async {
      final response = await http.get(Uri.parse('$exchangeRateApiUrl$currencyCode'));
   if (response.statusCode == 200) {
        return ExchangeRate.fromJson(json.decode(response.body));
      } else {
        throw Exception('Error al cargar la data del exchange');
      }
    }
  }