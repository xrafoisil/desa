import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/book.dart';

class ApiService{
  final String ApiUrl='https://www.googleapis.com/books/v1/volumes';

  Future<List<Book>> fetchBooks(String query) async{
   final response = await http.get(Uri.parse('$ApiUrl?q=$query'));

    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body)['items'];
      return data.map((item) => Book.fromJson(item)).toList();
    } else {
      throw Exception('Error no se encontraron los libros');
    }

  }
}

