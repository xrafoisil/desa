import 'package:flutter/material.dart';
import '../models/book.dart';

class BookListItem extends StatelessWidget {
  final Book book;
  final Function(Book) onBookSelected;

  BookListItem({required this.book, required this.onBookSelected});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(book.title),
      subtitle: Text(book.authors),
      isThreeLine: true,
      trailing: Icon(Icons.arrow_forward),
      onTap: () => onBookSelected(book),
    );
  }
}
