
import 'package:flutter/material.dart';
import 'book_list_item.dart';
import '../models/book.dart';

class BookList extends StatelessWidget {
  final List<Book> books;
  final Function(Book) onBookSelected;

  BookList({required this.books, required this.onBookSelected});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: books.length,
      itemBuilder: (context, index) {
        var book = books[index];
        return BookListItem(
          book: book,
          onBookSelected: onBookSelected,
        );
      },
    );
  }
}