import 'package:flutter/material.dart';
import '../widgets/book_list.dart';
import '../api_service.dart';
import '../models/book.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService apiService = ApiService();
  final TextEditingController _controller = TextEditingController();
  Future<List<Book>>? _books;
  Book? _selectedBook;

  void _searchBooks() {
    setState(() {
      _books = apiService.fetchBooks(_controller.text);
      _selectedBook = null; // Clear the selected book when new search starts
    });
  }

  void _selectBook(Book book) {
    setState(() {
      _selectedBook = book;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ejemplo API Google Books  '),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Column(
                children: [
                  TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      labelText: 'Busqueda de libros',
                      suffixIcon: IconButton(
                        icon: Icon(Icons.search),
                        onPressed: _searchBooks,
                      ),
                    ),
                    onSubmitted: (_) => _searchBooks(),
                  ),
                  Expanded(
                    child: _books == null
                        ? Center(child: Text('Ingresa una busqueda para iniciar'))
                        : FutureBuilder<List<Book>>(
                            future: _books,
                            builder: (context, snapshot) {
                              if (snapshot.connectionState == ConnectionState.waiting) {
                                return Center(child: CircularProgressIndicator());
                              } else if (snapshot.hasError) {
                                return Center(child: Text('Error: ${snapshot.error}'));
                              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                                return Center(child: Text('No hay libros disponibles'));
                              } else {
                                return BookList(
                                  books: snapshot.data!,
                                  onBookSelected: _selectBook,
                                );
                              }
                            },
                          ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 3,
              child: _selectedBook == null
                  ? Center(child: Text('Selecciona un libro para ver los detalles'))
                  : Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _selectedBook!.title,
                            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 16),
                          Text(
                            'Authors: ${_selectedBook!.authors}',
                            style: TextStyle(fontSize: 18),
                          ),
                          SizedBox(height: 16),
                          Text(
                            _selectedBook!.description,
                            style: TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}