class Book{
  final String title;
  final String authors;
  final String description;
  final String thumbnail;

  Book({
    required this.title,
    required this.authors,
    required this.description,
    required this.thumbnail,
  });

factory Book.fromJson(Map<String,dynamic> json){
  return Book(
    title: json['volumeInfo']['title'] ?? 'Titulo indisponible',
    authors: json['volumeInfo']['authors'] != null ? (json['volumeInfo']['authors'] as List).join(',') : 'Autores no disponible',
    description: json['volumeInfo']['description'] ?? 'Descripción no disponible',
    thumbnail: json['volumeInfo']['imageLinks'] != null ? json['volumeInfo']['imageLinks']['thumbnail'] : '',
  );

  }

}